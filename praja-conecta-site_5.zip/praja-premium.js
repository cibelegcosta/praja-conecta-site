/* ════════════════════════════════════════════════════════════════
   PRAJA CONECTA — PREMIUM LAYER (JS)
   Importe DEPOIS do script principal.
   Adiciona: reveal evoluído, magnetic buttons, tilt 3D nos cards,
   parallax do hero, scroll velocity, mouse light nos process cards,
   cursor reativo a imagens.
   ════════════════════════════════════════════════════════════════ */

(function() {
  'use strict';

  // Respeita preferência de movimento reduzido
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ───────── 1. REVEAL EVOLUÍDO ─────────
  // Substitui .reveal antigo por .reveal-up/.reveal-x/.reveal-blur com IntersectionObserver
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-in');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

  document.querySelectorAll('.reveal-up, .reveal-x, .reveal-blur').forEach(el => {
    revealObserver.observe(el);
  });

  // Stagger automático: cada filho ganha --i baseado no índice
  document.querySelectorAll('[data-stagger]').forEach(container => {
    Array.from(container.children).forEach((child, i) => {
      child.style.setProperty('--i', i);
    });
  });

  // ───────── 2. MAGNETIC BUTTONS ─────────
  if (!reducedMotion) {
    document.querySelectorAll('[data-magnetic]').forEach(btn => {
      const strength = parseFloat(btn.dataset.magnetic) || 0.35;
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        btn.style.setProperty('--mx', `${x * strength}px`);
        btn.style.setProperty('--my', `${y * strength}px`);
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.setProperty('--mx', '0px');
        btn.style.setProperty('--my', '0px');
      });
    });
  }

  // ───────── 3. TILT 3D NOS CARDS DAS SÓCIAS ─────────
  if (!reducedMotion) {
    document.querySelectorAll('[data-tilt]').forEach(card => {
      const maxTilt = 6; // graus
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        const rotY = x * maxTilt;
        const rotX = -y * maxTilt;
        card.style.transform = `perspective(1200px) rotateX(${rotX}deg) rotateY(${rotY}deg) translateZ(0)`;
      });
      card.addEventListener('mouseleave', () => {
        card.style.transform = '';
      });
    });
  }

  // ───────── 4. PARALLAX DO HERO ─────────
  const heroContent = document.querySelector('.hero-content');
  const heroVideo = document.querySelector('.hero-video');
  if (heroContent && !reducedMotion) {
    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const y = window.scrollY;
          if (y < window.innerHeight) {
            heroContent.style.transform = `translateY(${y * 0.35}px)`;
            heroContent.style.opacity = Math.max(0, 1 - y / (window.innerHeight * 0.7));
            if (heroVideo) {
              heroVideo.style.transform = `scale(1.05) translateY(${y * 0.18}px)`;
            }
          }
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }

  // ───────── 5. CARREGAMENTO DO VÍDEO HERO ─────────
  if (heroVideo) {
    heroVideo.addEventListener('loadeddata', () => {
      heroVideo.classList.add('loaded');
      document.body.classList.add('has-hero-video');
    });
    // Fallback se demorar
    setTimeout(() => {
      if (heroVideo.readyState >= 2) {
        heroVideo.classList.add('loaded');
        document.body.classList.add('has-hero-video');
      }
    }, 2500);
  }

  // ───────── 6. MOUSE LIGHT NOS PROCESS CARDS ─────────
  document.querySelectorAll('.process-card-pro').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      card.style.setProperty('--mouse-x', `${x}%`);
      card.style.setProperty('--mouse-y', `${y}%`);
    });
  });

  // ───────── 7. SCROLL VELOCITY (texto reage à velocidade) ─────────
  const velocityEls = document.querySelectorAll('.scroll-velocity');
  if (velocityEls.length && !reducedMotion) {
    let lastScroll = window.scrollY;
    let velocity = 0;
    let position = 0;

    function updateVelocity() {
      const current = window.scrollY;
      velocity = (current - lastScroll) * 0.5;
      lastScroll = current;
      position -= 0.4 + Math.abs(velocity) * 0.15;
      // Loop infinito
      velocityEls.forEach(el => {
        const width = el.scrollWidth / 2;
        if (Math.abs(position) > width) position = 0;
        el.style.transform = `translateX(${position}px)`;
      });
      requestAnimationFrame(updateVelocity);
    }
    requestAnimationFrame(updateVelocity);
  }

  // ───────── 8. CURSOR REATIVO + ATIVAÇÃO ─────────
  // Só mostra cursor custom após o primeiro mousemove (evita ficar preso no canto)
  const cursor = document.querySelector('.custom-cursor');
  const cursorFollower = document.querySelector('.custom-cursor-follower');
  if (cursor && !reducedMotion) {
    let activated = false;
    document.addEventListener('mousemove', () => {
      if (!activated) {
        document.body.classList.add('cursor-active');
        activated = true;
      }
    }, { once: false });
    // Esconde se o mouse sair da janela
    document.addEventListener('mouseleave', () => {
      document.body.classList.remove('cursor-active');
      cursor.classList.remove('over-image');
    });
    document.addEventListener('mouseenter', () => {
      if (activated) document.body.classList.add('cursor-active');
    });

    // Reativo a imagens, com cleanup defensivo
    document.querySelectorAll('[data-cursor="image"], .socia-foto-wrap, .mockup-frame').forEach(el => {
      el.addEventListener('mouseenter', () => cursor.classList.add('over-image'));
      el.addEventListener('mouseleave', () => cursor.classList.remove('over-image'));
    });
    // Safety: se ficar mais de 2s sem mousemove com over-image, remove
    let lastMove = Date.now();
    document.addEventListener('mousemove', () => { lastMove = Date.now(); });
    setInterval(() => {
      if (Date.now() - lastMove > 2000 && cursor.classList.contains('over-image')) {
        cursor.classList.remove('over-image');
      }
    }, 1000);
  }

  // ───────── 9. IMAGE REVEAL ─────────
  const imgRevealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-in');
        imgRevealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  document.querySelectorAll('.img-reveal').forEach(el => imgRevealObserver.observe(el));

  // ───────── 10. KPI COUNTER (números animam ao entrar na tela) ─────────
  const kpiObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseFloat(el.dataset.kpi);
        const duration = 1600;
        const start = performance.now();
        const suffix = el.dataset.suffix || '';
        const isFloat = target % 1 !== 0;

        function tick(now) {
          const progress = Math.min((now - start) / duration, 1);
          // Easing: ease-out-cubic
          const eased = 1 - Math.pow(1 - progress, 3);
          const value = target * eased;
          el.innerHTML = (isFloat ? value.toFixed(1) : Math.floor(value)) +
            (suffix ? `<span class="suffix">${suffix}</span>` : '');
          if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        kpiObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-kpi]').forEach(el => kpiObserver.observe(el));

  // ───────── 11. METODO TIMELINE: linha cresce conforme scroll na seção ─────────
  const timeline = document.querySelector('.metodo-timeline');
  if (timeline && !reducedMotion) {
    let timelineTicking = false;
    window.addEventListener('scroll', () => {
      if (!timelineTicking) {
        requestAnimationFrame(() => {
          const rect = timeline.getBoundingClientRect();
          const winH = window.innerHeight;
          const total = rect.height + winH * 0.4;
          const seen = winH - rect.top;
          const progress = Math.max(0, Math.min(1, seen / total)) * 100;
          timeline.style.setProperty('--progress', progress + '%');
          timelineTicking = false;
        });
        timelineTicking = true;
      }
    }, { passive: true });
  }

  // ───────── 12. SAFE-CALL: garante que reveal antigo (.reveal/.reveal-stagger) continue funcionando ─────────
  // Se o site ainda tiver .reveal sem nova classe, força aparecer
  const legacyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-in', 'active', 'visible');
        legacyObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal, .reveal-stagger').forEach(el => legacyObserver.observe(el));

})();
